class CustomToast extends HTMLElement {
    static get observedAttributes() {
        return ['message'];
    }

    // Fires when an instance of the element is created or updated
    constructor() {
        super();
        this.root = this.attachShadow({
            mode: 'open'
        });
        const style = document.createElement('style');
        style.textContent = CustomToast.getStyle();
        this.root.appendChild(style);
        const c3Toast = document.createElement('DIV');
        c3Toast.setAttribute('class', 'c3-toast');

        const notificationActionRenderer = document.createElement('DIV');
        notificationActionRenderer.setAttribute('class', 'notification-action-renderer');
        const notificationActionResponseText = document.createElement('DIV');
        notificationActionResponseText.setAttribute('class', 'notification-action-response-text');
        notificationActionRenderer.appendChild(notificationActionResponseText);
        c3Toast.appendChild(notificationActionRenderer);
        this.root.appendChild(c3Toast);

        this.c3Toast = c3Toast;
        this.notificationActionResponseText = notificationActionResponseText;
        this.messages = [];
        this.timer = 0;
    }

    // Fires when an instance was inserted into the document
    connectedCallback() {
    }

    // Fires when an instance was removed from the document
    disconnectedCallback() {
    }

    showMessage() {
        if (this.messages.length && !this.showing) {
            const message = this.messages.shift();
            this.notificationActionResponseText.textContent = message;
            this.c3Toast.setAttribute('dir', 'in');
            this.showing = true;
            if (this.timer) {
                clearTimeout(this.timer);
            }
            this.timer = setTimeout(() => {
                this.c3Toast.setAttribute('dir', 'out');
                setTimeout(() => {
                    this.showing = false;
                    this.showMessage();
                }, 195);
            }, 3000);
        }
    }

    // Fires when an attribute was added, removed, or updated
    attributeChangedCallback(attrName, oldVal, newVal) {
        if (attrName === 'message') {
            this.messages.push(newVal);
            this.showMessage();
        }
    }

    // Fires when an element is moved to a new document
    adoptedCallback() {
    }

    static getTemplate(value) {
        return `
${CustomToast.getStyle()}
<div>
    ${value}
</div>
`;
    }

    static getStyle() {
        return `
.c3-toast[dir="in"] {
    transition: margin 225ms cubic-bezier(0.0, 0.0, 0.2, 1);
    margin-top: 0;
}

.c3-toast[dir="out"] {
    transition: margin 195ms cubic-bezier(0.4, 0.0, 1, 1);
}

.c3-toast {
    display: block;
    position: fixed;
    z-index: 999;
    left: 0;
    right: 0;
    top: 0;
    box-sizing: border-box;
    padding: 14px 24px;
    font-size: 1.4rem;
    color: #ffffff;
    background: hsl(0, 0%, 20%);
    will-change: transform;
    margin-top: -100%;
}

.notification-action-renderer {
    display: flex;
    align-items: center;
}

.notification-action-response-text {
    flex-grow: 1;
    padding-right: 1rem;
    font-size:14px;
}

`;
    }
}

customElements.define('custom-toast', CustomToast);
/*
<!--
<custom-toast bind="customToast"></custom-toast>
<script src="custom-toast.js"></script>
customToast.setAttribute('message','');-
-->
*/