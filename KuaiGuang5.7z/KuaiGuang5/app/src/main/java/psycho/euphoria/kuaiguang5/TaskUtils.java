package psycho.euphoria.kuaiguang5;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Toast;

import static psycho.euphoria.kuaiguang5.Utils.checkIfColorIsRange;
import static psycho.euphoria.kuaiguang5.Utils.click;
import static psycho.euphoria.kuaiguang5.Utils.getRandomNumber;

public class TaskUtils {

    public static int convertX(int value) {
        // (1080 / 1088.0)
        return (int) (value * 1.027);
    }

    public static int convertY(int value) {
        return (int) (value * (2119 / 2030.0));
    }

    public static boolean checkIfMissionCenter(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "MissionCenter");
        if (checkIfColorIsRange(20, bitmap, new int[]{463, 94, 34, 34, 34,
                444, 109, 247, 247, 247,
                451, 113, 34, 34, 34,
                607, 95, 34, 34, 34,
                628, 131, 247, 247, 247})
                || checkIfColorIsRange(20, bitmap, new int[]{62, 97, 255, 255, 255,
                65, 105, 253, 54, 102,
                134, 112, 255, 255, 255,
                90, 118, 253, 54, 102,
                170, 137, 253, 54, 102})
        ) {
            Toast.makeText(accessibilityService, "任务中心", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    public static boolean checkIfClickToGetIt(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "ClickToGetIt");
        for (int i = 827; i < 925; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{i, 2051, 255, 241, 239})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{i + (857 - 836), 2051, 253, 87, 88,
                        i + (887 - 836), 2044, 255, 255, 255,
                        i + (890 - 836), 2044, 253, 73, 94,
                        i + (916 - 836), 2043, 255, 245, 247})) {
                    Toast.makeText(accessibilityService, "点可领", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(852, 852 + 100), getRandomNumber(2030,
                            2030 + 40));
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean checkIfWatchTheAds(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "WatchTheAds");
        for (int i = 643; i < 1818; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{857, i, 253, 54, 102})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{967, i + (1677 - 1647), 255, 255, 255,
                        80, i + (1644 - 1647), 34, 34, 34,
                        165, i + (1648 - 1647), 34, 34, 34,
                        243, i + (1684 - 1647), 34, 34, 34})) {
                    Toast.makeText(accessibilityService, "看广告得", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(857, 857 + 100), getRandomNumber(i, i + 40));
                    return true;
                }

            }
        }
        return false;
    }


    public static boolean checkIfGoWatchAdsAndEarnMore(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "GoWatchAdsAndEarnMore");
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{400, 1401, 253, 54, 102,
                401, 1464, 255, 227, 233,
                675, 1459, 255, 255, 255,
                652, 1490, 255, 255, 255,
                686, 1495, 253, 54, 102})
        ) {
            Toast.makeText(accessibilityService, "去看广告赚更多", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(309, 687), getRandomNumber(1404, 1533));
            return true;
        }
        return false;
    }


public static boolean checkIfRewardsSuccessfullyClaimed(AccessibilityService accessibilityService, Bitmap bitmap) {
Log.e("B5aOx2", "RewardsSuccessfullyClaimed");
if (Utils.checkIfColorIsRange(20,bitmap,new int[]{116,64,255,255,255,
        118,69,255,255,255,
        140,63,255,255,255,
        144,84,255,255,255})
        && Utils.checkColorLess(bitmap, 114,64,200)
) {
            Toast.makeText(accessibilityService, "已成功领取奖励", Toast.LENGTH_SHORT).show();
    click(accessibilityService, getRandomNumber(119,360), getRandomNumber(63,91));

    return true;
        }
        return false;
    }


public static boolean checkIfWatchAnotherOneAndGetGoldCoins(AccessibilityService accessibilityService, Bitmap bitmap) {
Log.e("B5aOx2", "WatchAnotherOneAndGetGoldCoins");
if (Utils.checkIfColorIsRange(20,bitmap,new int[]{474,1187,253,54,102,
        479,1204,255,255,255,
        603,1204,255,239,243,
        608,1203,253,54,102,
        537,1239,253,54,102})
) {
            Toast.makeText(accessibilityService, "再看一个再领取金币", Toast.LENGTH_SHORT).show();
    click(accessibilityService, getRandomNumber(294,788), getRandomNumber(1186,1258));

    return true;
        }
        return false;
    }

/*

*/
}