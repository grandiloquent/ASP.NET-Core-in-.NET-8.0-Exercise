/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package psycho.euphoria.kuaiguangn1;


import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.GestureResultCallback;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.GestureDescription.StrokeDescription;
import android.graphics.Path;
import android.graphics.PointF;
import android.view.Display;
import android.view.ViewConfiguration;

import java.util.Random;
import java.util.concurrent.CompletableFuture;

public class GestureUtils {

    public static final String LOG_TAG = "GestureUtils";
    private static final long STROKE_TIME_GAP_MS_DEFAULT = 40;
    private static final long STROKE_TIME_GAP_MS_MAX = ViewConfiguration.getDoubleTapTimeout() - 1;
    // Bounds for the amount of time between taps
    private static final long STROKE_TIME_GAP_MS_MIN = 1;
    static final long TAP_DURATION_MS_DEFAULT = ViewConfiguration.getTapTimeout();
    static final long TAP_DURATION_MS_MAX = ViewConfiguration.getTapTimeout();
    // Bounds for the duration of a tap.
    static final long TAP_DURATION_MS_MIN = 1;
    private static Random sRandom = null;
    // We generate the random seed later in randomize() and store it here to enable users to
    // reproduce randomized test failures.
    private static long sRandomSeed = 0;
    private static boolean sShouldRandomize = false;
    private static long sStrokeGapTimeMs = STROKE_TIME_GAP_MS_DEFAULT;
    private static long sTapDuration = TAP_DURATION_MS_DEFAULT;

    private GestureUtils() {
    }

    public static PointF add(PointF a, float x, float y) {
        return new PointF(a.x + x, a.y + y);
    }

    public static PointF add(PointF a, PointF b) {
        return add(a, b.x, b.y);
    }

    public static PointF ceil(PointF p) {
        return new PointF((float) Math.ceil(p.x), (float) Math.ceil(p.y));
    }

    public static StrokeDescription click(PointF point) {
        return new StrokeDescription(path(point), 0, sTapDuration);
    }

    public static PointF diff(PointF a, PointF b) {
        return add(a, -b.x, -b.y);
    }

    public static CompletableFuture<Void> dispatchGesture(
            AccessibilityService service, GestureDescription gesture) {
        CompletableFuture<Void> result = new CompletableFuture<>();
        GestureResultCallback callback =
                new GestureResultCallback() {
                    @Override
                    public void onCancelled(GestureDescription gestureDescription) {
                        result.cancel(false);
                    }

                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        result.complete(null);
                    }
                };
//        service.runOnServiceSync(
//                () -> {
//                    if (!service.dispatchGesture(gesture, callback, null)) {
//                        result.completeExceptionally(new IllegalStateException());
//                    }
//                });
        return result;
    }

    public static float distance(PointF a, PointF b) {
        if (a == null) throw new NullPointerException();
        if (b == null) throw new NullPointerException();
        return (float) Math.hypot(a.x - b.x, a.y - b.y);
    }

    public static GestureDescription kuaiguang5bleTap(PointF point) {
        return kuaiguang5bleTap(point, Display.DEFAULT_DISPLAY);
    }

    /**
     * Generates a kuaiguang5ble-tap gesture.
     */
    public static GestureDescription kuaiguang5bleTap(PointF point, int displayId) {
        return multiTap(point, 2, 0, displayId);
    }

    public static GestureDescription kuaiguang5bleTapAndHold(PointF point) {
        return kuaiguang5bleTapAndHold(point, Display.DEFAULT_DISPLAY);
    }

    /**
     * Generates a single-finger kuaiguang5ble-tap and hold gesture.
     */
    public static GestureDescription kuaiguang5bleTapAndHold(PointF point, int displayId) {
        GestureDescription.Builder builder = new GestureDescription.Builder();
        //builder.setDisplayId(displayId);
        StrokeDescription tap1 = click(point);
        StrokeDescription tap2 = startingAt(endTimeOf(tap1) + sStrokeGapTimeMs, longClick(point));
        builder.addStroke(tap1);
        builder.addStroke(tap2);
        return builder.build();
    }

    public static StrokeDescription drag(StrokeDescription from, PointF to) {
        return from.continueStroke(
                path(lastPointOf(from), to),
                endTimeOf(from),
                ViewConfiguration.getTapTimeout(),
                true);
    }

    public static long endTimeOf(StrokeDescription stroke) {
        return stroke.getStartTime() + stroke.getDuration();
    }

    public static GestureDescription.Builder getGestureBuilder(
            int displayId, StrokeDescription... strokes) {
        GestureDescription.Builder builder = new GestureDescription.Builder();
        //builder.setDisplayId(displayId);
        for (StrokeDescription s : strokes) builder.addStroke(s);
        return builder;
    }

    public static PointF getPointWithinSlop(PointF point, int slop) {
        return add(point, slop / 2, 0);
    }

    /**
     * Simulates a touch exploration swipe that is interrupted partway through for a specified
     * amount of time, and then continued.
     */
    public static GestureDescription interruptedSwipe(PointF from, PointF to, long duration) {
        GestureDescription.Builder builder = new GestureDescription.Builder();
        long time = 0;
        PointF midpoint = new PointF((from.x + to.x) / 2.0f, (from.y + to.y) / 2.0f);
        StrokeDescription swipe1 = new StrokeDescription(path(from, midpoint), 0, duration / 2);
        builder.addStroke(swipe1);
        time += swipe1.getDuration() + sStrokeGapTimeMs;
        StrokeDescription swipe2 = startingAt(time, swipe(midpoint, to, duration / 2));
        builder.addStroke(swipe2);
        return builder.build();
    }

    public static PointF lastPointOf(StrokeDescription stroke) {
        float[] p = stroke.getPath().approximate(0.3f);
        return new PointF(p[p.length - 2], p[p.length - 1]);
    }

    public static float length(PointF p) {
        return (float) Math.hypot(p.x, p.y);
    }

    public static StrokeDescription longClick(PointF point) {
        return new StrokeDescription(path(point), 0, ViewConfiguration.getLongPressTimeout() * 3);
    }

    /**
     * Simulates a user placing multiple fingers on the specified screen
     * and then multi-tapping with these fingers.
     * <p>
     * The location of fingers based on <code>basePoint<code/> are shifted by <code>delta<code/>.
     * Like (baseX, baseY), (baseX + deltaX, baseY + deltaY), and so on.
     *
     * @param basePoint   Where to place the first finger.
     * @param delta       Offset to basePoint where to place the 2nd or 3rd finger.
     * @param fingerCount The number of fingers.
     * @param tapCount    The number of taps to fingers.
     * @param slop        Slop range the finger tapped.
     * @param displayId   Which display to dispatch the gesture.
     */
    public static GestureDescription multiFingerMultiTap(
            PointF basePoint,
            PointF delta,
            int fingerCount,
            int tapCount,
            int slop,
            int displayId) {

        final int strokeCount = fingerCount * tapCount;
        final PointF[] pointers = new PointF[fingerCount];
        final StrokeDescription[] strokes = new StrokeDescription[strokeCount];
        // The first tap
        for (int i = 0; i < fingerCount; i++) {
            pointers[i] = add(basePoint, times(i, delta));
            strokes[i] = click(pointers[i]);
        }
        // The rest of taps
        for (int tapIndex = 1; tapIndex < tapCount; tapIndex++) {
            for (int i = 0; i < fingerCount; i++) {
                final StrokeDescription lastStroke = strokes[(tapIndex - 1) * fingerCount + i];
                final long nextStartTime = endTimeOf(lastStroke) + sStrokeGapTimeMs;
                final int nextIndex = tapIndex * fingerCount + i;
                pointers[i] = getPointWithinSlop(pointers[i], slop);
                strokes[nextIndex] = startingAt(nextStartTime, click(pointers[i]));
            }
        }
        return getGestureBuilder(displayId, strokes).build();
    }

    /**
     * Simulates a user placing multiple fingers on the specified screen
     * and then multi-tapping and holding with these fingers.
     * <p>
     * The location of fingers based on <code>basePoint<code/> are shifted by <code>delta<code/>.
     * Like (baseX, baseY), (baseX + deltaX, baseY + deltaY), and so on.
     *
     * @param basePoint   Where to place the first finger.
     * @param delta       Offset to basePoint where to place the 2nd or 3rd finger.
     * @param fingerCount The number of fingers.
     * @param tapCount    The number of taps to fingers.
     * @param slop        Slop range the finger tapped.
     * @param displayId   Which display to dispatch the gesture.
     */
    public static GestureDescription multiFingerMultiTapAndHold(
            PointF basePoint,
            PointF delta,
            int fingerCount,
            int tapCount,
            int slop,
            int displayId) {
        final int strokeCount = fingerCount * tapCount;
        final PointF[] pointers = new PointF[fingerCount];
        final StrokeDescription[] strokes = new StrokeDescription[strokeCount];
        // The first tap
        for (int i = 0; i < fingerCount; i++) {
            pointers[i] = add(basePoint, times(i, delta));
            if (tapCount == 1) {
                strokes[i] = longClick(pointers[i]);
            } else {
                strokes[i] = click(pointers[i]);
            }
        }
        // The rest of taps
        for (int tapIndex = 1; tapIndex < tapCount; tapIndex++) {
            for (int i = 0; i < fingerCount; i++) {
                final StrokeDescription lastStroke = strokes[(tapIndex - 1) * fingerCount + i];
                final long nextStartTime = endTimeOf(lastStroke) + sStrokeGapTimeMs;
                final int nextIndex = tapIndex * fingerCount + i;
                pointers[i] = getPointWithinSlop(pointers[i], slop);
                if (tapIndex + 1 == tapCount) {
                    // Last tap so do long click.
                    strokes[nextIndex] = startingAt(nextStartTime, longClick(pointers[i]));
                } else {
                    strokes[nextIndex] = startingAt(nextStartTime, click(pointers[i]));
                }
            }
        }
        return getGestureBuilder(displayId, strokes).build();
    }

    public static GestureDescription multiTap(PointF point, int taps) {
        return multiTap(point, taps, 0);
    }

    public static GestureDescription multiTap(PointF point, int taps, int slop) {
        return multiTap(point, taps, 0, Display.DEFAULT_DISPLAY);
    }

    /**
     * Generates a single-finger multi-tap gesture.
     */
    public static GestureDescription multiTap(PointF point, int taps, int slop, int displayId) {
        GestureDescription.Builder builder = new GestureDescription.Builder();
        //builder.setDisplayId(displayId);
        long time = 0;
        if (taps > 0) {
            // Place first tap on the point itself.
            // Subsequent taps will be offset somewhere within slop radius.
            // If slop is 0 subsequent taps will also be on the point itself.
            StrokeDescription stroke = click(point);
            builder.addStroke(stroke);
            time += stroke.getDuration() + sStrokeGapTimeMs;
            for (int i = 1; i < taps; i++) {
                stroke = click(getPointWithinSlop(point, slop));
                builder.addStroke(startingAt(time, stroke));
                time += stroke.getDuration() + sStrokeGapTimeMs;
            }
        }
        return builder.build();
    }

    public static PointF negate(PointF p) {
        return times(-1, p);
    }

    public static Path path(PointF first, PointF... rest) {
        Path path = new Path();
        path.moveTo(first.x, first.y);
        for (PointF point : rest) {
            path.lineTo(point.x, point.y);
        }
        return path;
    }

    public static StrokeDescription pointerDown(PointF point) {
        return new StrokeDescription(path(point), 0, ViewConfiguration.getTapTimeout(), true);
    }

    public static StrokeDescription pointerUp(StrokeDescription lastStroke) {
        return lastStroke.continueStroke(
                path(lastPointOf(lastStroke)),
                endTimeOf(lastStroke),
                ViewConfiguration.getTapTimeout(),
                false);
    }

    /**
     * Simulates a user placing one finger on the screen for a specified amount of time and then
     * multi-tapping with a second finger.
     *
     * @param explorePoint Where to place the first finger.
     * @param tapPoint     Where to tap with the second finger.
     * @param taps         The number of second-finger taps.
     * @param waitTime     How long to hold the first finger before tapping with the second finger.
     */
    public static GestureDescription secondFingerMultiTap(
            PointF explorePoint, PointF tapPoint, int taps, int waitTime) {
        GestureDescription.Builder builder = new GestureDescription.Builder();
        long time = waitTime;
        for (int i = 0; i < taps; i++) {
            StrokeDescription stroke = click(tapPoint);
            builder.addStroke(startingAt(time, stroke));
            time += stroke.getDuration();
            time += ViewConfiguration.getDoubleTapTimeout() / 3;
        }
        builder.addStroke(swipe(explorePoint, explorePoint, time));
        return builder.build();
    }

    public static StrokeDescription startingAt(long timeMs, StrokeDescription prototype) {
        return new StrokeDescription(
                prototype.getPath(), timeMs, prototype.getDuration(), prototype.willContinue());
    }

    public static StrokeDescription swipe(PointF from, PointF to) {
        return swipe(from, to, ViewConfiguration.getTapTimeout());
    }

    public static StrokeDescription swipe(PointF from, PointF to, long duration) {
        return new StrokeDescription(path(from, to), 0, duration);
    }

    public static PointF times(float mult, PointF p) {
        return new PointF(p.x * mult, p.y * mult);
    }

    public static GestureDescription tripleTap(PointF point) {
        return tripleTap(point, Display.DEFAULT_DISPLAY);
    }

    /**
     * Generates a triple-tap gesture.
     */
    public static GestureDescription tripleTap(PointF point, int displayId) {
        return multiTap(point, 3, 0, displayId);
    }


}
