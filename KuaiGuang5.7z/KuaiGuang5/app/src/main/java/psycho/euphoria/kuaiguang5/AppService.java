package psycho.euphoria.kuaiguang5;
/*
adb shell settings put secure enabled_accessibility_services psycho.euphoria.kuaiguang5/psycho.euphoria.kuaiguang5.AppService
 */

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.hardware.display.DisplayManager;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static psycho.euphoria.kuaiguang5.Utils.createNotificationChannel;
import static psycho.euphoria.kuaiguang5.Utils.getRandomNumber;

public class AppService extends AccessibilityService {

    Handler mHandler;
    ExecutorService mExecutorService;
    long mDelay;
    long mTime;
    int mCount;
    int mIsSaveImage = 0;

    private void dumpDisplays() {
        DisplayManager disp = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        Display[] allDisplays = disp.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        for (Display dl : allDisplays) {
            Log.e("B5aOx2", "Display name: " + allDisplays.length + " " + dl.getName() + " Display id: " + dl.getDisplayId());
        }
    }

    private void process(ScreenshotResult screenshot) {
        final Bitmap bitmap = Bitmap.wrapHardwareBuffer(screenshot.getHardwareBuffer(),
                screenshot.getColorSpace()).copy(Bitmap.Config.ARGB_8888, false);
        try {
            if (TaskUtils.checkIfMissionCenter(this, bitmap)) {
// 任务中心
                if (TaskUtils.checkIfClickToGetIt(this, bitmap)) {
// 点可领
                } else if (TaskUtils.checkIfWatchTheAds(this, bitmap)) {
// 看广告得
                }
            } else if (TaskUtils.checkIfGoWatchAdsAndEarnMore(this, bitmap)) {
// 去看广告赚更多
            }else if (TaskUtils.checkIfRewardsSuccessfullyClaimed(this, bitmap)) {
// 已成功领取奖励

            }else if (TaskUtils.checkIfWatchAnotherOneAndGetGoldCoins(this, bitmap)) {
// 再看一个再领取金币

            }
        } catch (Exception exception) {
        }
        if (mIsSaveImage > 0 && mIsSaveImage < 4) {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES
            ), "Screenshots");
            int index = 1;
            File src = new File(dir, String.format("%03d.%s", index, "png"));
            while (src.exists()) {
                index++;
                src = new File(dir, String.format("%03d.%s", index, "png"));
            }
            FileOutputStream os = null;
            try {
                os = new FileOutputStream(src);
                bitmap.compress(CompressFormat.PNG, 100, os);
                os.close();
            } catch (Exception e) {
            }
            if (mIsSaveImage > 3)
                mIsSaveImage = 0;
            else mIsSaveImage++;
        }
        bitmap.recycle();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public int onStartCommand(final Intent intent, final int flags, final int startId) {
        int result = START_NOT_STICKY;
        final String action = intent != null ? intent.getAction() : null;
        if ((this.getPackageName() + ".STOP").equals(action)) {
            stopForeground(true);
            android.os.Process.killProcess(android.os.Process.myPid());
        } else if ((this.getPackageName() + ".PHOTO").equals(action)) {
            mIsSaveImage = 1;
        } else if ((this.getPackageName() + ".START").equals(action)) {
            createNotificationChannel(this);
            Toast.makeText(this, "已成功启动", Toast.LENGTH_SHORT).show();
            mHandler = new Handler();
            mExecutorService = Executors.newSingleThreadExecutor();
            new Thread(() -> {
                mTime = System.currentTimeMillis();
                mDelay = getRandomNumber(3, 5) * 1000L;
                Log.e("B5aOx2", String.format("onStartCommand, %s %s", mTime, mDelay));
                while (true) {
                    if (System.currentTimeMillis() - mTime > mDelay) {
                        mCount++;
                        Log.e("B5aOx2", String.format("onStartCommand, %s %s %s", mTime, mDelay, mCount));
                        mDelay = getRandomNumber(3, 5) * 1000L;
                        mTime = System.currentTimeMillis();
                        takeScreenshot(Display.DEFAULT_DISPLAY,
                                AppService.this.getApplication().getMainExecutor(), new TakeScreenshotCallback() {
                                    @Override
                                    public void onFailure(int i) {
                                        Log.e("B5aOx2", String.format("onFailure, %s", i));
                                    }

                                    @Override
                                    public void onSuccess(ScreenshotResult screenshotResult) {
                                        process(screenshotResult);
                                    }
                                });
                    }
                }
            }).start();

        }
        return result;
    }


}