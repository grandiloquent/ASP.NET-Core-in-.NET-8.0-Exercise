package psycho.euphoria.kuaiguang0;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.ImageReader.OnImageAvailableListener;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

import static psycho.euphoria.kuaiguang0.Utils.click;
import static psycho.euphoria.kuaiguang0.Utils.createNotificationChannel;
import static psycho.euphoria.kuaiguang0.Utils.getBitmap;
import static psycho.euphoria.kuaiguang0.Utils.getMediaProjection;
import static psycho.euphoria.kuaiguang0.Utils.getRandomNumber;
import static psycho.euphoria.kuaiguang0.Utils.getVirtualDisplay;

public class AppService extends AccessibilityService {

    Handler mHandler;
    ExecutorService mExecutorService;
    long mDelay;
    long mTime;
    public int mCount;
    int mWidth = 1080;
    int mHeight = 2310;
    int mDensityDpi = 0;
    int mIsSaveImage = 0;

    private void doTake(Intent intent) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                takeScreenshot(intent);
            }
        }).start();

    }

    private void dumpDisplays() {
        DisplayManager disp = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        Display[] allDisplays = disp.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        for (Display dl : allDisplays) {
            Log.e("B5aOx2", "Display name: " + allDisplays.length + " " + dl.getName() + " Display id: " + dl.getDisplayId());
        }
    }

    private void look(Bitmap bitmap) {
        if (TaskUtils.checkIfMissionCenter(this, bitmap)) {
// 任务中心
            if (TaskUtils.checkIfClickToGetIt(this, bitmap)) {
// 点可领
            } else if (TaskUtils.checkIfWatchTheAds(this, bitmap)) {
// 看广告得
            }
            mCount = 0;
        } else if (TaskUtils.checkIfGoWatchAdsAndEarnMore(this, bitmap)) {
// 去看广告赚更多
        } else if (TaskUtils.checkIfRewardsSuccessfullyClaimed(this, bitmap)) {
// 已成功领取奖励
        } else if (TaskUtils.checkIfGiveUpReward(this, bitmap)) {
// 放弃奖励
        } else if (TaskUtils.checkIfWatchAnotherOne(this, bitmap)) {
// 再看一个
            mCount = 0;
        } else if (TaskUtils.checkIfReceived(this, bitmap)) {
// 已领取
        }  else if (TaskUtils.checkIfExitTheLiveBroadcastRoom(this, bitmap)) {
// 退出直播间
        }
        else if (TaskUtils.checkIfGuessYouLike(this, bitmap)) {
// 猜你喜欢

        }

        else if (TaskUtils.checkIfWatchLiveBroadcast(this, bitmap)) {
// 看直播
            mCount++;
            if (mCount > 30) {
                mCount = 0;
                click(this, getRandomNumber(997, 1030), getRandomNumber(146, 178));
            }

        }
    }

    private void process(Bitmap bitmap) {
        look(bitmap);
        if (mIsSaveImage > 0 && mIsSaveImage < 4) {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES
            ), "Screenshots");
            int index = 1;
            File src = new File(dir, String.format("%03d.%s", index, "png"));
            while (src.exists()) {
                index++;
                src = new File(dir, String.format("%03d.%s", index, "png"));
            }
            FileOutputStream os = null;
            try {
                os = new FileOutputStream(src);
                bitmap.compress(CompressFormat.PNG, 100, os);
                bitmap.recycle();
                os.close();
            } catch (Exception e) {
            }
            if (mIsSaveImage > 3)
                mIsSaveImage = 0;
            else mIsSaveImage++;
        }
        bitmap.recycle();

    }

    Bitmap mBitmap;

    private void takeScreenshot(Intent intent) {
        final CountDownLatch latch = new CountDownLatch(1);
        MediaProjection projection = getMediaProjection(AppService.this, intent, getPackageName() + ".EXTRA_RESULT_CODE");
        ImageReader reader = ImageReader.newInstance(mWidth, mHeight, PixelFormat.RGBA_8888, 2,
                HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE | HardwareBuffer.USAGE_GPU_COLOR_OUTPUT);
        VirtualDisplay vd = projection.createVirtualDisplay(
                "ScreenShot", mWidth, mHeight,
                mDensityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null
        );
        reader.setOnImageAvailableListener(new OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                try {
                    Image image = reader.acquireLatestImage();
                    mBitmap = Bitmap.wrapHardwareBuffer(image.getHardwareBuffer(),
                            null).copy(Bitmap.Config.ARGB_8888, false);
                    mBitmap.copy(Bitmap.Config.ARGB_8888, false);
                } catch (Exception ignored) {
                }
                latch.countDown();
            }
        }, mHandler);
        try {
            latch.await();
        } catch (InterruptedException e) {
        }
        reader.close();
        vd.release();
        projection.stop();
        mHandler.post(() -> process(mBitmap));
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
        doTake(intent);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Display display = ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getRealMetrics(displayMetrics);
        mWidth = displayMetrics.widthPixels;
        mHeight = displayMetrics.heightPixels;
        mDensityDpi = displayMetrics.densityDpi;
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public int onStartCommand(final Intent intent, final int flags, final int startId) {
        int result = START_NOT_STICKY;
        final String action = intent != null ? intent.getAction() : null;
        if ((this.getPackageName() + ".STOP").equals(action)) {
            stopForeground(true);
            android.os.Process.killProcess(android.os.Process.myPid());
        } else if ((this.getPackageName() + ".PHOTO").equals(action)) {
            mIsSaveImage = 1;
        } else if ((this.getPackageName() + ".START").equals(action)) {
            createNotificationChannel(this);
            Toast.makeText(this, "已成功启动", Toast.LENGTH_SHORT).show();
            mHandler = new Handler();
            mExecutorService = Executors.newSingleThreadExecutor();
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    doTake(intent);
                }

            }, 3000);
        }
        return result;
    }

}