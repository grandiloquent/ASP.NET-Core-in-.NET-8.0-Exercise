package psycho.euphoria.kuaiguang0;

import android.Manifest.permission;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

import static psycho.euphoria.kuaiguang0.Utils.isDeviceRooted;
import static psycho.euphoria.kuaiguang0.Utils.requestAccessibilityPermission;


public class MainActivity extends Activity {
    private static final int REQUEST_CODE_SCREEN_CAPTURE = 1;


    private void createScreenshotRequest() {
        final MediaProjectionManager manager
                = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        final Intent permissionIntent = manager.createScreenCaptureIntent();
        startActivityForResult(permissionIntent, REQUEST_CODE_SCREEN_CAPTURE);

    }

    private void startScreenRecorder(int resultCode, Intent data) {
        final Intent intent = new Intent(this, psycho.euphoria.kuaiguang0.AppService.class);
        intent.setAction(getPackageName() + ".START");
        intent.putExtra(getPackageName() + ".EXTRA_RESULT_CODE", resultCode);
        intent.putExtras(data);
        startService(intent);
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (REQUEST_CODE_SCREEN_CAPTURE == requestCode) {
            if (resultCode != Activity.RESULT_OK) {
                // when no permission
                Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
                return;
            }
            startScreenRecorder(resultCode, data);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Utils.requestStoragePermission(this);
        //TaskUtils.testGiveUpReward();
        if (isDeviceRooted()) {
            requestAccessibilityPermission(this, AppService.class);
        } else {
            requestAccessibilityPermission(this);
        }
        if (checkSelfPermission(permission.FOREGROUND_SERVICE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    permission.FOREGROUND_SERVICE
            }, 0);
        }
        Intent intent = new Intent(this, AppService.class);
        startService(intent);
        createScreenshotRequest();
    }


}