package psycho.euphoria.kuaiguang0;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Toast;

import static psycho.euphoria.kuaiguang0.Utils.checkIfColorIsRange;
import static psycho.euphoria.kuaiguang0.Utils.click;
import static psycho.euphoria.kuaiguang0.Utils.getRandomNumber;

public class TaskUtils {

    public static boolean checkIfClickToGetIt(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "ClickToGetIt");
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{420, 502, 0, 0, 0,
                415, 481, 255, 237, 237,
                429, 551, 255, 237, 237,
                455, 503, 0, 0, 0,
                471, 495, 255, 235, 237})) {
            Toast.makeText(accessibilityService, "点可领", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(964, 1020), getRandomNumber(358, 412));
            return true;
        }
        for (int i = 843; i < 956; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{i, 2242, 255, 255, 255})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{i + (872 - 851), 2242, 253, 85, 89,
                        i + (902 - 851), 2235, 255, 255, 255,
                        i + (904 - 851), 2235, 253, 72, 95,
                        i + (933 - 851), 2255, 253, 56, 101})) {
                    Toast.makeText(accessibilityService, "点可领", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(860, 960), getRandomNumber(2230, 2270));
                    return true;
                }
            }
        }
        return false;
    }

    /*

     */
    public static boolean checkIfGiveUpReward(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "GiveUpReward");
        for (int i = 1371; i < 1725; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{470, i, 165, 165, 165})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{485, i + (1573 - 1575), 255, 255, 255,
                        501, i + (1575 - 1575), 163, 163, 163,
                        504, i + (1571 - 1575), 255, 255, 255,
                        606, i + (1577 - 1575), 155, 155, 155})) {
                    Toast.makeText(accessibilityService, "放弃奖励", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(470, 470 + 100), getRandomNumber(i, i + 20));
                    break;
                }
                i += 964 - 882;
            }
        }
        return false;
    }

    /*
    else
    */
    public static boolean checkIfGoWatchAdsAndEarnMore(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "GoWatchAdsAndEarnMore");
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{386, 1520, 253, 54, 102,
                401, 1557, 255, 255, 255,
                664, 1553, 255, 255, 255,
                708, 1554, 253, 54, 102,
                598, 1589, 253, 54, 102})
        ) {
            Toast.makeText(accessibilityService, "去看广告赚更多", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(390, 680), getRandomNumber(1511, 1629));
            return true;
        }
        return false;
    }

    public static boolean checkIfMissionCenter(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "MissionCenter");
        if (checkIfColorIsRange(20, bitmap, new int[]{461, 138, 34, 34, 34,
                464, 148, 247, 247, 247,
                564, 135, 34, 34, 34,
                569, 170, 247, 247, 247,
                631, 166, 34, 34, 34})
        ) {
            Toast.makeText(accessibilityService, "任务中心", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    public static boolean checkIfRewardsSuccessfullyClaimed(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "RewardsSuccessfullyClaimed");
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{137, 177, 255, 255, 255,
                165, 178, 255, 255, 255,
                165, 191, 255, 255, 255,
                139, 191, 255, 255, 255,
        }) && Utils.checkColorLess(bitmap, 134, 196, 200)
        ) {
            Toast.makeText(accessibilityService, "已成功领取奖励", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(138, 420), getRandomNumber(178, 208));
            return true;
        }
        return false;
    }

    /*

     */
    public static boolean checkIfWatchAnotherOne(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "WatchAnotherOne");
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{466, 1325, 255, 255, 255,
                472, 1322, 253, 54, 102,
                611, 1326, 255, 255, 255,
                619, 1325, 253, 54, 102,
                620, 1363, 253, 54, 102})
        ) {
            Toast.makeText(accessibilityService, "再看一个", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(267, 828), getRandomNumber(1311, 1381));
            return true;
        }
        return false;
    }

    public static boolean checkIfWatchLiveBroadcast(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "WatchLiveBroadcast");
        if (Utils.checkIfColorIsRange(50, bitmap, new int[]{997, 145, 239, 239, 245,
                1013, 161, 241, 241, 247,
                1031, 144, 241, 241, 245,
                1031, 179, 241, 241, 247,
        }) && Utils.checkColorTotal(bitmap, 1013, 168, 750)
        ) {
            Toast.makeText(accessibilityService, "看直播", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    public static boolean checkIfWatchTheAds(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "WatchTheAds");
        for (int i = 296; i < 2035; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{852, i, 253, 54, 102})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{
                        964, i + (1659 - 1630) + 1, 255, 255, 255,
                        902, i + (1692 - 1630), 255, 255, 255,
                        127, i + (1631 - 1630) + 1, 44, 44, 44,
                        239, i + (1664 - 1630), 34, 34, 34})) {
                    Toast.makeText(accessibilityService, "看广告得", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(852, 852 + 100), getRandomNumber(i, i + 40));
                    return true;
                }

            }
        }
        return false;
    }

    /*

     */
    public static boolean checkIfReceived(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "Received");
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{953, 409, 255, 255, 255,
                992, 384, 255, 177, 76,
                992, 397, 251, 177, 75,
                995, 410, 255, 255, 255,
                1008, 390, 247, 179, 75})
        ) {
            Toast.makeText(accessibilityService, "已领取", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(997, 1030), getRandomNumber(146, 178));
            return true;
        }
        return false;
    }

    public static boolean checkIfExitTheLiveBroadcastRoom(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "ExitTheLiveBroadcastRoom");
        for (int i = 1475; i < 1679; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{448, i, 102, 102, 102})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{478, i + (1527 - 1527), 255, 255, 255,
                        632, i + (1529 - 1527), 102, 102, 102,
                        636, i + (1529 - 1527), 255, 255, 255,
                        626, i + (1558 - 1527), 102, 102, 102})) {
                    Toast.makeText(accessibilityService, "退出直播间", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(448, 448 + 100), getRandomNumber(i, i + 30));
                    return true;
                }

            }
        }
        return false;
    }


    public static boolean checkIfGuessYouLike(AccessibilityService accessibilityService, Bitmap bitmap) {
        Log.e("B5aOx2", "GuessYouLike");
        for (int i = 1487; i < 1686; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{506, i, 102, 102, 102})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{511, i + (1527 - 1527), 255, 255, 255,
                        534, i + (1527 - 1527), 102, 102, 102,
                        539, i + (1528 - 1527), 255, 255, 255,
                        574, i + (1557 - 1527), 102, 102, 102})) {
                    click(accessibilityService, getRandomNumber(506, 506 + 60), getRandomNumber(i, i + 20));
                    return true;
                }

            }
        }
        return false;
    }

}