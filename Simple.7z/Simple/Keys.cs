﻿ 
using System;


	/// <summary>
	/// Description of Keys.
	/// </summary>
	public static class KeyShare
	{
		public const string AppId="1301282710";
		public const string SecretKey="gClTHYxJpJi1ihckEfI3xsfLwgXasLrf";
		public const string SecretId="AKIDnYAoYG4QlElhbYimsuq5IOk7V1V5ZzWE";
	}
  