package psycho.euphoria.dou10;

import android.Manifest.permission;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.GestureResultCallback;
import android.accessibilityservice.GestureDescription;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.hardware.display.VirtualDisplay.Callback;
import android.media.Image;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.ViewConfiguration;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.util.Random;
import java.util.function.Function;

import static android.Manifest.permission.POST_NOTIFICATIONS;
import static android.content.Context.NOTIFICATION_SERVICE;
import static android.os.Build.VERSION.SDK_INT;


public class Utils {
    public static final int SUCCESS = 0;
    private static final String LINE_SEP = System.getProperty("line.separator");

    public static boolean checkColorLess(Bitmap bitmap, int x, int y, int value) {
        int color = bitmap.getPixel(x, y);
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        return red < value && green < value && blue < value;
    }

    public static boolean checkColorTotal(Bitmap bitmap, int x, int y, int value) {
        int color = bitmap.getPixel(x, y);
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        return red + green + blue < value;
    }

    public static boolean checkIfColorIsRange(int offset, Bitmap bitmap, int... values) {
        for (int i = 0; i < values.length; i += 5) {
            int color = bitmap.getPixel(values[i], values[i + 1]);
            int red = Color.red(color);
            int green = Color.green(color);
            int blue = Color.blue(color);
            if (red < values[i + 2] - offset || red > values[i + 2] + offset)
                return false;
            if (green < values[i + 3] - offset || green > values[i + 3] + offset)
                return false;
            if (blue < values[i + 4] - offset || blue > values[i + 4] + offset)
                return false;
        }
        return true;

    }

    public static boolean checkIfColorIsRange(int offset, Bitmap bitmap, boolean log, int... values) {
        for (int i = 0; i < values.length; i += 5) {
            int color = bitmap.getPixel(values[i], values[i + 1]);
            int red = Color.red(color);
            int green = Color.green(color);
            int blue = Color.blue(color);
            if (log) {
                Log.e("B5aOx2", String.format("checkIfColorIsRange, %s %s %s %s %s %s", values[i], values[i + 1],
                        red, green, blue, color));
            }
            if (red < values[i + 2] - offset || red > values[i + 2] + offset)
                return false;
            if (green < values[i + 3] - offset || green > values[i + 3] + offset)
                return false;
            if (blue < values[i + 4] - offset || blue > values[i + 4] + offset)
                return false;
        }
        return true;

    }

    public static boolean checkIfColorIsRange(Bitmap bitmap, int x, int y, Function<Integer, Boolean> fr,
                                              Function<Integer, Boolean> fg, Function<Integer, Boolean> fb) {
        int color = bitmap.getPixel(x, y);
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        return fr.apply(red) && fg.apply(green) && fb.apply(blue);
        /*
        checkIfColorIsRange(decoded, 290, 1720, (red) -> {
                                return red > 200;
                            }, (green) -> {
                                return green < 80;
                            }, (blue) -> {
                                return blue < 100;

         */
    }

    @TargetApi(Build.VERSION_CODES.N)
    public static void click(AccessibilityService accessibilityService, int x, int y) {
        Log.e("B5aOx2", String.format("click, %s %s", x, y));
        GestureDescription.Builder builder = new GestureDescription.Builder();
        Path p = new Path();
        p.moveTo(x, y);
        builder.addStroke(new GestureDescription.StrokeDescription(p, 0, ViewConfiguration.getTapTimeout()));
        GestureDescription gesture = builder.build();
        boolean isDispatched = accessibilityService.dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
            }

            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
            }
        }, null);
    }

    public static void createNotificationChannel(Service context) {
        Notification.Builder builder = new Notification.Builder(context.getApplicationContext()); //获取一个Notification构造器
        builder.setContentTitle(context.getResources().getString(R.string.app_name))
                .setSmallIcon(R.drawable.ic_swipe_up)
                .addAction(0, "停止", PendingIntent.getService(context, 0, new Intent(context, AppService.class)
                        .setAction(context.getPackageName() + ".STOP"), PendingIntent.FLAG_IMMUTABLE))
                .addAction(0, "截图", PendingIntent.getService(context, 0, new Intent(context, AppService.class)
                        .setAction(context.getPackageName() + ".PHOTO"), PendingIntent.FLAG_IMMUTABLE))
        ;
        /*以下是对Android 8.0的适配*/
        //普通notification适配
        if (SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(context.getPackageName());
        }
        //前台服务notification适配
        if (SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel(context.getPackageName(), context.getResources().getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW);
            notificationManager.createNotificationChannel(channel);
        }
        Notification notification = builder.build(); // 获取构建好的Notification
        notification.defaults = Notification.DEFAULT_SOUND; //设置为默认的声音
        context.startForeground(110, notification);
    }

    public static void dumpColors(Bitmap bitmap, int... values) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < values.length; i += 5) {
            int color = bitmap.getPixel(values[i], values[i + 1]);
            stringBuilder.append(
                    String.format("%d %d Color: %d = %d %d %d\n", values[i], values[i + 1], color,
                            Color.red(color), Color.green(color), Color.blue(color))
            );
        }
        Log.e("B5aOx2", String.format("%s", stringBuilder));
    }

    public static void enableNotification(Context context) {
        try {
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
            intent.putExtra(Settings.EXTRA_CHANNEL_ID, context.getApplicationInfo().uid);
            intent.putExtra("app_package", context.getPackageName());
            intent.putExtra("app_uid", context.getApplicationInfo().uid);
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", context.getPackageName(), null);
            intent.setData(uri);
            context.startActivity(intent);
        }
    }

    public static CommandResult execCmd(final String[] commands, final boolean isRoot) {
        return execCmd(commands, isRoot, true);
    }

    public static CommandResult execCmd(final String command, final boolean isRoot) {
        return execCmd(new String[]{command}, isRoot, true);
    }

    public static CommandResult execCmd(final String[] commands, final boolean isRoot, final boolean isNeedResultMsg) {
        int result = -1;
        if (commands == null || commands.length == 0) {
            return new CommandResult(result, null, null);
        }
        Process process = null;
        BufferedReader successResult = null;
        BufferedReader errorResult = null;
        StringBuilder successMsg = null;
        StringBuilder errorMsg = null;
        DataOutputStream os = null;
        try {
            process = Runtime.getRuntime().exec(isRoot ? "su" : "sh");
            os = new DataOutputStream(process.getOutputStream());
            for (String command : commands) {
                if (command == null) continue;
                os.write(command.getBytes());
                os.writeBytes(LINE_SEP);
                os.flush();
            }
            os.writeBytes("exit" + LINE_SEP);
            os.flush();
            result = process.waitFor();
            if (isNeedResultMsg) {
                successMsg = new StringBuilder();
                errorMsg = new StringBuilder();
                successResult = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
                errorResult = new BufferedReader(new InputStreamReader(process.getErrorStream(), "UTF-8"));
                String line;
                if ((line = successResult.readLine()) != null) {
                    successMsg.append(line);
                    while ((line = successResult.readLine()) != null) {
                        successMsg.append(LINE_SEP).append(line);
                    }
                }
                if ((line = errorResult.readLine()) != null) {
                    errorMsg.append(line);
                    while ((line = errorResult.readLine()) != null) {
                        errorMsg.append(LINE_SEP).append(line);
                    }
                }
            }
        } catch (Exception e) {
        } finally {
            try {
                os.close();
                successResult.close();
                errorResult.close();
            } catch (Exception e) {
            }
            if (process != null) {
                process.destroy();
            }
        }
        return new CommandResult(
                result,
                successMsg == null ? null : successMsg.toString(),
                errorMsg == null ? null : errorMsg.toString());
    }

    public static Bitmap getBitmap(Image image, int width, int height) {
        final Image.Plane[] planes = image.getPlanes();
        final Buffer buffer = planes[0].getBuffer().rewind();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride,
                height, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        return bitmap;
    }

    public static MediaProjection getMediaProjection(Context context, Intent intent, String name) {
        final int resultCode = intent.getIntExtra(name, 0);
        MediaProjectionManager mediaProjectionManager = (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        return mediaProjectionManager.getMediaProjection(resultCode, intent);
    }

    public static int getRandomNumber(int min, int max) {
        Random random = new Random(System.currentTimeMillis());
        return random.nextInt(max - min + 1) + min;
    }

    public static VirtualDisplay getVirtualDisplay(MediaProjection projection, DisplayMetrics metrics, Surface surface, Handler handler) {
        VirtualDisplay.Callback callback = new Callback() {
            @Override
            public void onPaused() {
                super.onPaused();
            }

            @Override
            public void onResumed() {
                super.onResumed();
            }

            @Override
            public void onStopped() {
                super.onStopped();
            }
        };
        VirtualDisplay vd = projection.createVirtualDisplay("screen", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, callback, handler);
        return vd;
    }

    public static boolean isAccessibilitySettingsOn(Context context, Class<? extends android.accessibilityservice.AccessibilityService> clazz) {
        int accessibilityEnabled = 0;
        final String service = context.getPackageName() + "/" + clazz.getCanonicalName();
        try {
            accessibilityEnabled = Settings.Secure.getInt(context.getApplicationContext().getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        TextUtils.SimpleStringSplitter mStringColonSplitter = new TextUtils.SimpleStringSplitter(':');
        if (accessibilityEnabled == 1) {
            String settingValue = Settings.Secure.getString(context.getApplicationContext().getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue);
                while (mStringColonSplitter.hasNext()) {
                    String accessibilityService = mStringColonSplitter.next();
                    if (accessibilityService.equalsIgnoreCase(service)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean isDeviceRooted() {
        String su = "su";
        String[] locations = {"/system/bin/", "/system/xbin/", "/sbin/", "/system/sd/xbin/",
                "/system/bin/failsafe/", "/data/local/xbin/", "/data/local/bin/", "/data/local/"};
        for (String location : locations) {
            if (new File(location + su).exists()) {
                return true;
            }
        }
        return false;
    }

    public static void requestAccessibilityPermission(Context context) {
        if (!isAccessibilitySettingsOn(context, psycho.euphoria.dou10.AppService.class)) {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY);
            context.startActivity(intent);
        }

    }

    public static void requestAccessibilityPermission(Context ct, Class service) {
        String cmd1 = "settings put secure enabled_accessibility_services  ";
        String cmd2 = "settings put secure accessibility_enabled 0";
        String cmd3 = "settings put secure enabled_accessibility_services  " + ct.getPackageName() + "/" + service.getName();
        String cmd4 = "settings put secure accessibility_enabled 1";
        String[] cmds = new String[]{cmd1, cmd2, cmd3, cmd4};
        execCmd(cmds, true);
    }

    public static void requestNotificationPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= 33) {
            if (activity.checkSelfPermission(POST_NOTIFICATIONS) == PackageManager.PERMISSION_DENIED) {
                if (!activity.shouldShowRequestPermissionRationale(POST_NOTIFICATIONS)) {
                    enableNotification(activity);
                } else {
                    activity.requestPermissions(new String[]{POST_NOTIFICATIONS}, 100);
                }
            }
        } else {
            boolean enabled = activity.getSystemService(NotificationManager.class).areNotificationsEnabled();
            if (!enabled) {
                enableNotification(activity);
            }
        }
    }

    public static void requestStoragePermission(Activity context) {
        if (SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Uri uri = Uri.parse("package:" + context.getPackageName());
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri);
                    context.startActivity(intent);
                } catch (Exception ex) {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    context.startActivity(intent);
                }
            }
        } else {
            if (context.checkSelfPermission(permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                context.requestPermissions(new String[]{
                        permission.WRITE_EXTERNAL_STORAGE
                }, 0);

            }
        }
    }

    @TargetApi(Build.VERSION_CODES.N)
    public static void swipe(AccessibilityService accessibilityService, int x1, int y1, int x2, int y2) {
        GestureDescription.Builder builder = new GestureDescription.Builder();
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        builder.addStroke(new GestureDescription.StrokeDescription(p, getRandomNumber(50, 100), getRandomNumber(300, 500)));
//        Path q = new Path();
//        q.moveTo(x1, y1);
//        q.lineTo(x2, y2);
//        builder.addStroke(new GestureDescription.StrokeDescription(q, 100L, ViewConfiguration.getTapTimeout()));
        GestureDescription gesture = builder.build();
        boolean isDispatched = accessibilityService.dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
            }

            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
            }
        }, null);
    }

    public static class CommandResult {

        // 结果码
        public int result;
        // 成功信息
        public String successMsg;
        // 错误信息
        public String errorMsg;

        public CommandResult(final int result, final String successMsg, final String errorMsg) {
            this.result = result;
            this.successMsg = successMsg;
            this.errorMsg = errorMsg;
        }

        /**
         * 判断是否执行成功
         *
         * @return
         */
        public boolean isSuccess() {
            return result == SUCCESS;
        }

        /**
         * 判断是否执行成功(判断 errorMsg)
         *
         * @return
         */
        public boolean isSuccess2() {
            if (result == SUCCESS && (errorMsg == null || errorMsg.length() == 0)) {
                return true;
            }
            return false;
        }

        /**
         * 判断是否执行成功(判断 successMsg)
         *
         * @return
         */
        public boolean isSuccess3() {
            if (result == SUCCESS && successMsg != null && successMsg.length() != 0) {
                return true;
            }
            return false;
        }

        /**
         * 判断是否执行成功(判断 successMsg) , 并且 successMsg 是否包含某个字符串
         *
         * @param contains
         * @return
         */
        public boolean isSuccess4(final String contains) {
            if (result == SUCCESS && successMsg != null && successMsg.length() != 0) {
                if (contains != null && contains.length() != 0 && successMsg.toLowerCase().contains(contains)) {
                    return true;
                }
            }
            return false;
        }
    }
}