package psycho.euphoria.dou10;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Toast;

import static psycho.euphoria.dou10.Utils.checkIfColorIsRange;
import static psycho.euphoria.dou10.Utils.click;
import static psycho.euphoria.dou10.Utils.dumpColors;
import static psycho.euphoria.dou10.Utils.getRandomNumber;
import static psycho.euphoria.dou10.Utils.swipe;

public class TaskUtils {

    public static boolean checkIf(AccessibilityService accessibilityService, Bitmap bitmap) {
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{519, 2258, 253, 253, 253,
                538, 2308, 255, 40, 46,
                549, 2263, 253, 253, 251,
                555, 2252, 255, 67, 79,
                564, 2307, 255, 42, 53})) {
            Toast.makeText(accessibilityService, "看视频", Toast.LENGTH_SHORT).show();
            swipe(accessibilityService, getRandomNumber(310, 788), getRandomNumber(1687, 1691), getRandomNumber(278, 824), getRandomNumber(432, 455));
            int value = getRandomNumber(0, 100);
            if (value > 50) {
                if (Utils.checkIfColorIsRange(20, bitmap, new int[]{981, 1111, 253, 44, 85,
                        995, 1111, 253, 233, 237,
                        1009, 1111, 253, 44, 85,
                        995, 1096, 253, 44, 85,
                        995, 1125, 253, 44, 85})) {
                    Toast.makeText(accessibilityService, "关注", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(974, 1017), getRandomNumber(1093, 1131));
                    return true;
                }

            }
            value = getRandomNumber(0, 100);
            if (value < 50) {
                if (Utils.checkIfColorIsRange(20, bitmap, new int[]{968, 1201, 239, 241, 241,
                        998, 1204, 239, 241, 241,
                        1024, 1202, 237, 237, 237,
                        998, 1226, 239, 241, 241,
                        998, 1257, 237, 239, 239})) {
                    Toast.makeText(accessibilityService, "点赞", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(968, 1026), getRandomNumber(1208, 1250));
                    return true;
                }

            }
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{389, 441, 255, 247, 223,
                271, 1489, 255, 87, 129,
                700, 438, 255, 241, 205,
                671, 1487, 255, 62, 92,
                674, 1583, 255, 64, 93})) {
            Toast.makeText(accessibilityService, "恭喜你获得", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(296, 761), getRandomNumber(1485, 1597));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{62, 166, 28, 30, 39,
                60, 165, 255, 255, 255,
                69, 166, 247, 247, 247,
                85, 189, 22, 24, 34,
                72, 166, 255, 255, 255})) {
            Toast.makeText(accessibilityService, "下载应用", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(66, 86), getRandomNumber(148, 183));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{
                815, 124, 255, 255, 255,
                933, 128, 255, 255, 255,
                991, 140, 255, 255, 255,
                943, 154, 255, 255, 255})
                && Utils.checkColorTotal(bitmap, 946, 158, 600)
        ) {
            Toast.makeText(accessibilityService, "领取成功", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(803, 1000), getRandomNumber(102, 173));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{834, 126, 255, 255, 255,
                952, 133, 255, 255, 255,
                945, 153, 255, 255, 255,
                990, 139, 255, 255, 255})
                && Utils.checkColorTotal(bitmap, 990, 143, 600)
        ) {
            Toast.makeText(accessibilityService, "领取成功 抖音商城", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(831, 1006), getRandomNumber(102, 178));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{387, 1596, 255, 249, 241,
                382, 1601, 253, 44, 85,
                698, 1595, 253, 44, 85,
                693, 1597, 255, 249, 241,
                693, 1633, 253, 44, 85})) {
            Toast.makeText(accessibilityService, "评价并收下金币", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(300, 751), getRandomNumber(1562, 1664));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{934, 1916, 217, 37, 91,
                934, 1917, 217, 37, 91,
                932, 1919, 255, 207, 108,
                933, 1919, 255, 207, 108,
                934, 1919, 255, 209, 108})) {
            Toast.makeText(accessibilityService, "逛街完成", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(62, 122), getRandomNumber(128, 200));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{932, 1871, 255, 213, 126,
                932, 1858, 255, 203, 114,
                912, 1886, 255, 65, 113,
                953, 1882, 255, 63, 112,
                941, 1892, 255, 213, 113})) {
            Toast.makeText(accessibilityService, "逛街上滑", Toast.LENGTH_SHORT).show();
            swipe(accessibilityService, getRandomNumber(121, 728), getRandomNumber(1800, 2105),
                    getRandomNumber(121, 728), getRandomNumber(400, 650));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{467, 1452, 69, 70, 79,
                471, 1448, 255, 255, 255,
                612, 1483, 69, 70, 79,
                618, 1486, 255, 255, 255,
                515, 1380, 253, 44, 85})) {
            Toast.makeText(accessibilityService, "执意退出", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(466, 610), getRandomNumber(1455, 1483));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{277, 962, 127, 64, 66,
                803, 968, 127, 64, 66,
                810, 968, 255, 249, 241,
                441, 1311, 255, 255, 255,
                441, 1297, 255, 48, 82})) {
            Toast.makeText(accessibilityService, "再看一个视频继续领奖励", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(293, 772), getRandomNumber(1276, 1382));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{940, 548, 0, 0, 0,
                1036, 546, 0, 0, 0,
                985, 545, 255, 251, 251,
                978, 506, 255, 239, 219,
                981, 521, 255, 175, 73})) {
            Toast.makeText(accessibilityService, "广告视频", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(950, 1035), getRandomNumber(480, 561));
            return true;
        }
        if (Utils.checkIfColorIsRange(20, bitmap, new int[]{498, 659, 255, 215, 74,
                488, 750, 251, 100, 90,
                637, 771, 241, 221, 78,
                561, 823, 253, 75, 48,
                306, 883, 251, 165, 104}) && !Utils.checkIfColorIsRange(20, bitmap, new int[]{533, 998, 255, 255, 255,
                533, 1007, 255, 153, 28,
                614, 1002, 255, 255, 255,
                577, 1005, 255, 151, 25,
                556, 1007, 255, 153, 28})) {
            Toast.makeText(accessibilityService, "收金币", Toast.LENGTH_SHORT).show();
            click(accessibilityService, getRandomNumber(379, 692), getRandomNumber(880, 1015));
            return true;
        }
        for (int i = 218; i < 473; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{i, 1471, 255, 77, 71})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{i + (294 - 292), 1471, 255, 255, 255,
                        i + (329 - 292), 1469, 255, 249, 249,
                        i + (331 - 292), 1469, 255, 85, 76,
                        i + (327 - 292), 1509, 255, 255, 255})) {
                    Toast.makeText(accessibilityService, "看广告视频再得", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(256, 256 + 500), getRandomNumber(1430, 1430 + 120));
                    return true;
                }
            }
        }
        for (int i = 850; i < 2096; i++) {
            if (checkIfColorIsRange(20, bitmap, new int[]{861, i, 253, 44, 85})) {
                if (checkIfColorIsRange(20, bitmap, new int[]{912, i + (1897 - 1867), 255, 255, 255,
                        979, i + (1930 - 1867), 255, 255, 255,
                        366, i + (1912 - 1867), 80, 82, 90,
                        389, i + (1929 - 1867), 80, 82, 90,
                        820, i + (850 - 1867), 255, 255, 255,
                        861, i + (2096 - 1867), 255, 255, 255})) {
                    Toast.makeText(accessibilityService, "逛街赚钱", Toast.LENGTH_SHORT).show();
                    click(accessibilityService, getRandomNumber(861, 861 + 100), getRandomNumber(i, i + 40));
                    return true;
                }
            }
        }
        return false;
    }


}