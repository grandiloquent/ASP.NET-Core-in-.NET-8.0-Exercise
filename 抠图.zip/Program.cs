﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;

namespace 抠图
{
	class Program
	{
		
		public static void Main(string[] args)
		{
			string colors = "655758";
			var list = new List<int[]>();
			foreach (var element in colors.Split(' ')) {
				list.Add(HexToColor(element));
			}
			int offset = 15;
			using (var bx = Bitmap.FromFile(@"C:\Users\Administrator\Desktop\555\3.png")) {
				using (var b = new Bitmap(bx.Width, bx.Height, PixelFormat.Format32bppArgb)) {
					using (var g = Graphics.FromImage(b)) {
						g.DrawImage(bx, new Rectangle(0, 0, bx.Width, bx.Height));
						PixelUtil pixelUtil = new PixelUtil(b);
						pixelUtil.LockBits();
			
						for (int i = 0; i < b.Width; i++) {
							for (int j = 0; j < b.Height; j++) {
								Color firstPixel = pixelUtil.GetPixel(i, j);
								/*
						var bb = false;
						foreach (var element in list) {
							if ((element[0] - offset <= firstPixel.R && firstPixel.R <= element[0] + offset)
							    &&
							    (element[1] - offset <= firstPixel.G && firstPixel.G <= element[1] + offset)
							    &&
							    (element[2] - offset <= firstPixel.B && firstPixel.B <= element[2] + offset)) {
								pixelUtil.SetPixel(i, j, Color.Black);
								bb = true;
								break;
							}
						}
						if (!bb)
							pixelUtil.SetPixel(i, j, Color.White);
							firstPixel.R<=200 && (firstPixel.R-firstPixel.G<20)
						  
						  && (firstPixel.B<180)
						  
						*/
								var min = 100;
								var max = 200;
								var f1 = true;
								if (firstPixel.A == 0) {
									f1 = false;
								}
//								var f1=firstPixel.R >= min && firstPixel.R <= max
//								 && firstPixel.B >= min && firstPixel.B <= max
//									&& firstPixel.G >= min && firstPixel.G <= max;
								var f2 = true;
//								if(firstPixel.R/20==10  && firstPixel.B/19==10 && firstPixel.G/19==10){
//									f2=false;
//								}
								var f3 = true;
//								if(firstPixel.R/18==10  && firstPixel.B/17==10 && firstPixel.G/17==10){
//									f3=false;
//								}
								var f4 = true;
//								if(firstPixel.R/19==10  && firstPixel.B/18==10 && firstPixel.G/18==10){
//									f4=false;
//								}
								var f5 = true;
//								if( firstPixel.R-firstPixel.B<20 ){
//									f5=false;
//								}
								var f6 = true;
//								if(firstPixel.B> 198){
//									f6=false;
//								}
								// Color.FromArgb(0, 255, 255, 255)
//								if (f1 && f2 &&f3 && f4 && f5 && f6)
//								  
//									pixelUtil.SetPixel(i, j, Color.FromArgb(255, 0, 0, 0));
//								else
//									pixelUtil.SetPixel(i, j, Color.FromArgb(0, 0, 0, 0));

								if ((firstPixel.R+5) /10==24
								    && firstPixel.G/10==23
								    && firstPixel.B/10==24) {
									
									pixelUtil.SetPixel(i, j, Color.FromArgb(0, 0, 0, 0));
									
								} else if (firstPixel.B != 0)
									
								pixelUtil.SetPixel(i, j, Color.FromArgb(255, 0, 0, 0));
							}
						}

			

						//Don't forget to unlock!
						pixelUtil.UnlockBits();
						
						b.SetResolution(72, 72);
						b.Save(@"C:\Users\Administrator\Desktop\555\33.png", System.Drawing.Imaging.ImageFormat.Png);
					}
				
				}
			
			}
			
			
				
		}
		public static int[] HexToColor(string hex)
		{
			// Check for valid format (including optional # prefix)
			if (hex == null || !hex.StartsWith("#") && hex.Length != 3 && hex.Length != 6) {
				throw new ArgumentException("Invalid hex color format.");
			}

			// Remove optional # prefix
			hex = hex.StartsWith("#") ? hex.Substring(1) : hex;

			// Convert each substring of 2 characters to a byte value
			int red = Convert.ToInt32(hex.Substring(0, 2), 16);
			int green = Convert.ToInt32(hex.Substring(2, 2), 16);
			int blue = Convert.ToInt32(hex.Length == 3 ? hex.Substring(0, 1) + hex.Substring(0, 1) : hex.Substring(4, 2), 16);

			return new int[]{ red, green, blue };
		}

		
	}


	public class PixelUtil
	{
		Bitmap source = null;
		IntPtr Iptr = IntPtr.Zero;
		BitmapData bitmapData = null;

		public byte[] Pixels { get; set; }
		public int Depth { get; private set; }
		public int Width { get; private set; }
		public int Height { get; private set; }

		/// <summary>
		/// Pixel marshaling class, use this to get and set pixels rapidly.
		/// </summary>
		/// <param name="source">The Bitmap to work with</param>
		public PixelUtil(Bitmap source)
		{
			this.source = source;
		}

		/// <summary>
		/// Lock bitmap data
		/// </summary>
		public void LockBits()
		{
			try {
				// Get width and height of bitmap
				Width = source.Width;
				Height = source.Height;

				// get total locked pixels count
				int PixelCount = Width * Height;

				// Create rectangle to lock
				var rect = new Rectangle(0, 0, Width, Height);

				// get source bitmap pixel format size
				Depth = System.Drawing.Image.GetPixelFormatSize(source.PixelFormat);

				// Check if bpp (Bits Per Pixel) is 8, 24, or 32
				if (Depth != 8 && Depth != 24 && Depth != 32) {
					throw new ArgumentException("Only 8, 24 and 32 bpp images are supported.");
				}

				// Lock bitmap and return bitmap data
				bitmapData = source.LockBits(rect, ImageLockMode.ReadWrite,
					source.PixelFormat);

				// create byte array to copy pixel values
				int step = Depth / 8;
				Pixels = new byte[PixelCount * step];
				Iptr = bitmapData.Scan0;

				// Copy data from pointer to array
				Marshal.Copy(Iptr, Pixels, 0, Pixels.Length);
			} catch (Exception) {
				throw;
			}
		}

		/// <summary>
		/// Unlock bitmap data
		/// </summary>
		public void UnlockBits()
		{
			try {
				// Copy data from byte array to pointer
				Marshal.Copy(Pixels, 0, Iptr, Pixels.Length);

				// Unlock bitmap data
				source.UnlockBits(bitmapData);
			} catch (Exception) {
				throw;
			}
		}

		/// <summary>
		/// Get the color of the specified pixel
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <returns></returns>
		public Color GetPixel(int x, int y)
		{
			Color clr = Color.Empty;

			// Get color components count
			int cCount = Depth / 8;

			// Get start index of the specified pixel
			int i = ((y * Width) + x) * cCount;

			if (i > Pixels.Length - cCount)
				throw new IndexOutOfRangeException();

			if (Depth == 32) { //For 32 bpp get Red, Green, Blue and Alpha
				byte b = Pixels[i];
				byte g = Pixels[i + 1];
				byte r = Pixels[i + 2];
				byte a = Pixels[i + 3]; // a
				clr = Color.FromArgb(a, r, g, b);
			}
			if (Depth == 24) { //For 24 bpp get Red, Green and Blue
				byte b = Pixels[i];
				byte g = Pixels[i + 1];
				byte r = Pixels[i + 2];
				clr = Color.FromArgb(r, g, b);
			}
			if (Depth == 8) { //For 8 bpp get color value (Red, Green and Blue values are the same)
				byte c = Pixels[i];
				clr = Color.FromArgb(c, c, c);
			}
			return clr;
		}

		/// <summary>
		/// Set the color of the specified pixel
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="color"></param>
		public void SetPixel(int x, int y, Color color)
		{
			//Get color components count
			int cCount = Depth / 8;

			//Get start index of the specified pixel
			int i = ((y * Width) + x) * cCount;

			if (Depth == 32) { //For 32 bpp set Red, Green, Blue and Alpha
				Pixels[i] = color.B;
				Pixels[i + 1] = color.G;
				Pixels[i + 2] = color.R;
				Pixels[i + 3] = color.A;
			}
			if (Depth == 24) { //For 24 bpp set Red, Green and Blue
				Pixels[i] = color.B;
				Pixels[i + 1] = color.G;
				Pixels[i + 2] = color.R;
			}
			if (Depth == 8) { //For 8 bpp set color value (Red, Green and Blue values are the same)
				Pixels[i] = color.B;
			}
		}
	}

}